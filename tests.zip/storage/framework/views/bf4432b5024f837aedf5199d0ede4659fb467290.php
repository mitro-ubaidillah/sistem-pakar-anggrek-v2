<div class="bg-second-alternative" id="kontak">
    <div class="container text-center pt-5 pb-5">
        <h3 class="text-center pb-4">Kontak Kami</h3>
        <div class="row">
            <div class="col-12 col-md-6 col-sm-6 text-start pb-4">
                <p>
                    <img src="<?php echo e(asset('img/icon/fb.png')); ?>" alt="email" class="pe-2">
                    <b class="pe-2">Email</b>
                    <em>anggrek@gmail.com</em>
                </p>
                <p>
                    <img src="<?php echo e(asset('img/icon/wa.png')); ?>" alt="WA" class="pe-2">
                    <b class="pe-2">WA</b>
                    <em>088792356</em>
                </p>
                <p>
                    <img src="<?php echo e(asset('img/icon/fb.png')); ?>" alt="FB" class="pe-2">
                    <b class="pe-2">Facebook</b>
                    <em>Fatih Orchid</em>
                </p>
            </div>
            <div class="col-12 col-md-6 col-sm-6 pb-4">
                <h5>Temukan kami di:</h5>
                <span>Fatih Orchid</span>
                <p class="tex-center">Dsn Minggirsari Kec Kanigoro Kab Blitar</p>
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2027928.7027891946!2d113.58324044999999!3d-6.914709!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e78eb9f6ae0d51d%3A0x9f5f966f139c40b9!2sFatih%20Orchid!5e0!3m2!1sid!2sid!4v1658289720262!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<footer class="bg-one pt-3 pb-3 pe-5 text-end">
    <span class="footer">Anggrek 2022 &copy; power by MT</span>
</footer><?php /**PATH E:\kuliah\project skripsi\sistem-pakar-anggrek-v2\sistem-pakar-anggrek-v2\resources\views/partials/footer.blade.php ENDPATH**/ ?>