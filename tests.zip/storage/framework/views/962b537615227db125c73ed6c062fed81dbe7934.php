
<?php $__env->startSection('content'); ?>
    <main class="mb-5 mt-4">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card border-0 shadow rounded">
                        <div class="card-header bg-one">
                            <?php echo $__env->make('partials.navAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="card-body">
                        <a href="<?php echo e(route('penyakit.index')); ?>" class="btn bg-one font-color-default-w fw-semibold mb-3">Kembali Ke Halaman Penyakit</a>
                        <h3 class="text-center font-color-default">Edit Penyakit</h3>
                            <form action="<?php echo e(route('penyakit.update', $penyakit->id)); ?>" method="POST" novalidate>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row mt-5 mb-5">
                                    <div class="col-lg-8 m-auto">
                                        <div class="col-12 mb-3">
                                            <label class="label-input form-label">Nama Penyakit</label>
                                            <input type="text" name="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('nama',$penyakit->nama)); ?>">
                                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <label class="label-input form-label">Keterangan Penyakit</label>
                                            <textarea class="form-control" name="keterangan" aria-label="With textarea" required><?php echo e(old('keterangan',$penyakit->keterangan)); ?></textarea>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <label class="label-input form-label">Penanganan Penyakit</label>
                                            <textarea class="form-control" name="penanganan" aria-label="With textarea" required><?php echo e(old('penanganan',$penyakit->penanganan)); ?></textarea>
                                        </div>
                                        <div class="col-lg-12 text-end">
                                            <a href="<?php echo e(route('penyakit.index')); ?>" class="btn bg-danger-new font-color-default-w fw-semibold">Batal</a>
                                            <button type="submit" class="btn bg-second fw-semibold font-color-default">Ubah</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\kuliah\project skripsi\sistem-pakar-anggrek-v2\sistem-pakar-anggrek-v2\resources\views/admin/penyakit/edit.blade.php ENDPATH**/ ?>