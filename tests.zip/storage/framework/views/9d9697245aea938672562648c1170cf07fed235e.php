
<?php $__env->startSection('content'); ?>
<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<main class="mb-5 mt-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-header bg-one">
                        <?php echo $__env->make('partials.navAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <h3 class="text-center font-color-default"><?php echo e($title); ?></h3>
                        <a href="<?php echo e(route('symptom.create')); ?>" class="btn bg-one font-color-default-w fw-semibold mb-3"><i class="bi bi-plus-square"></i> Tambah Data Gejala</a>
                        <table class="table table-bordered">
                            <thead class="text-center">
                                <tr>
                                    <th scope="col" width="1%">No</th>
                                    <th scope="col">Gejala</th>
                                    <th scope="col">Penyakit</th>
                                    <th scope="col">Bagian</th>
                                    <th scope="col">Tingkat Keyakinan Pakar</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(++$no + ($symptoms->currentPage()-1)* $symptoms->perPage()); ?></td>
                                        <td><?php echo e($symptom->name); ?></td>
                                        <td class="text-center"><?php echo e($symptom->disease->name); ?></td>
                                        <td class="text-center"><?php echo e($symptom->section); ?></td>
                                        <?php switch($symptom->cf_role):
                                            case (0.2): ?>
                                                <td class="text-center">10%-20%</td>
                                                <?php break; ?>
                                            <?php case (0.4): ?>
                                                <td class="text-center">30%-40%</td>
                                                <?php break; ?>
                                            <?php case (0.6): ?>
                                                <td class="text-center">50%-60%</td>
                                                <?php break; ?>
                                            <?php case (0.8): ?>
                                                <td class="text-center">70%-80%</td>
                                                <?php break; ?>
                                            <?php default: ?>
                                                <td class="text-center">90%-100%</td>
                                        <?php endswitch; ?>
                                        <td class="text-center">
                                            <form onsubmit="return confirm('Apakah Anda yakin akan menghapus data ini ?');" action="<?php echo e(route('symptom.destroy', $symptom->id)); ?>" method="POST">
                                                <a href="<?php echo e(route('symptom.edit', $symptom->id)); ?>" class="btn btn-primary"><i class="bi bi-pencil-square"></i></a>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger"><i class="bi bi-trash-fill"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="alert alert-danger">
                                        Data Gejala belum Tersedia
                                    </div>
                                <?php endif; ?>
                            </tbody>
                        </table>  
                        <div class="clear"></div>
                        <?php echo e($symptoms->links()); ?>

                        <a href="/admin/dashboard" class="btn bg-second fw-semibold float-end">Kembali ke halaman admin</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\kuliah\project skripsi\sistem-pakar-anggrek-v2\sistem-pakar-anggrek-v2\resources\views/admin/symptom/index.blade.php ENDPATH**/ ?>