
<?php $__env->startSection('content'); ?>
    <main class="mb-5">
        <div class="container">
            <div class="card  border-0 shadow rounded">
                <div class="card-header bg-one">
                    <?php echo $__env->make('partials.navAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body p-5">
                    <div class="row">
                        <div class="col-6 text-center">
                            <img src="<?php echo e(asset('img/img-1.png')); ?>" alt="" width="500">
                        </div>
                        <div class="col-6 m-auto">
                            <div class="row">
                                <div class="col-sm-12 mb-3">
                                    <a href="<?php echo e(route('disease.index')); ?>" class="btn btn-custom-one w-100"><i class="bi bi-journal-medical"></i> Lihat Penyakit yang terdaftar</a>
                                </div>
                                <div class="col-6 mb-3">
                                    <a href="<?php echo e(route('symptom.index')); ?>" class="btn btn-custom-one w-100"><i class="bi bi-clipboard-pulse"></i> Lihat Gejala yang terdaftar</a>
                                </div>
                                <div class="col-6 mb-3">
                                    <a href="<?php echo e(route('cases.index')); ?>" class="btn btn-custom-one w-100"><i class="bi bi-clipboard2-check"></i> Lihat Kasus yang terdaftar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\kuliah\project skripsi\sistem-pakar-anggrek-v2\sistem-pakar-anggrek-v2\resources\views/admin/index.blade.php ENDPATH**/ ?>