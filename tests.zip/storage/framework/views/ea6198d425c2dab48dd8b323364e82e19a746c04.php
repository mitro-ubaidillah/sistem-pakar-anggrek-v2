
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid bg-one">
        <h1 class="font-color-default-w p-5 text-center">Halaman Hasil Diagnosa</h1>
    </div>
    <div class="container mb-5">
        <div class="accordion" id="accordionPanelsStayOpenExample">
            <div class="accordion-item">
              <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                  <strong>Kemungkinan Tanaman Anggrek Anda Terkena Penyakit <?php echo e(ucwords($finalResult[0]['disease'])); ?></strong>
                </button>
              </h2>
              <?php
                    $dataGejala1 = explode(",",$finalResult[0]['symptoms']);
                    $dataCFRoles1 = explode(",",$finalResult[0]['cf_roles']);
                    $dataCFUsers1 = explode(",",$finalResult[0]['cf_users']);
                    $no = 1;
              ?>
              <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show" aria-labelledby="panelsStayOpen-headingOne">
                <div class="accordion-body">
                    <h4>Penyakit <?php echo e(ucwords($finalResult[0]['disease'])); ?></h4>
                    <p>Gejala terkait yang dipilih pengguna :</p>
                    <table class="table table-bordered">
                        <thead class="text-center">
                            <th width="1%">No</th>
                            <th>Gejala</th>
                            <th>Tingkat Keyakinan Pakar</th>
                            <th>Tingkat Keyakinan Pengguna</th>
                        </thead>
                        <tbody>
                            <?php for($i = 0; $i < count($dataGejala1); $i++): ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($dataGejala1[$i]); ?></td>
                                    <?php switch($dataCFRoles1[$i]):
                                        case (0.2): ?>
                                            <td class="text-center">10%-20%</td>
                                            <?php break; ?>
                                        <?php case (0.4): ?>
                                            <td class="text-center">30%-40%</td>
                                            <?php break; ?>
                                        <?php case (0.6): ?>
                                            <td class="text-center">50%-60%</td>
                                            <?php break; ?>
                                        <?php case (0.8): ?>
                                            <td class="text-center">70%-80%</td>
                                            <?php break; ?>
                                        <?php default: ?>
                                            <td class="text-center">90%-100%</td>
                                    <?php endswitch; ?>
                                    <?php switch($dataCFUsers1[$i]):
                                        case (0.2): ?>
                                            <td class="text-center">10%-20%</td>
                                            <?php break; ?>
                                        <?php case (0.4): ?>
                                            <td class="text-center">30%-40%</td>
                                            <?php break; ?>
                                        <?php case (0.6): ?>
                                            <td class="text-center">50%-60%</td>
                                            <?php break; ?>
                                        <?php case (0.8): ?>
                                            <td class="text-center">70%-80%</td>
                                            <?php break; ?>
                                        <?php default: ?>
                                            <td class="text-center">90%-100%</td>
                                    <?php endswitch; ?>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                    <h5>Presentase Perhitungan Sistem</h5>
                    <p>Kemiripan dengan kasus sebelumnya :</p>
                    <div class="progress">
                        <div class="progress-bar bg-one"  style="width: <?php echo e($finalResult[0]['result_cbr']*100); ?>%;font-size:1rem;" role="progressbar"  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?php echo e($finalResult[0]['result_cbr']*100); ?>%</div>
                    </div>
                    <p>Hasil perhitungan algoritma Certainty Factor :</p>
                    <div class="progress">
                        <div class="progress-bar bg-one" role="progressbar" style="width: <?php echo e($finalResult[0]['result_cf']*100); ?>%; font-size:1rem;" aria-valuemin="0" aria-valuemax="100"><?php echo e($finalResult[0]['result_cf']*100); ?>%</div>
                    </div>
                    <?php $__currentLoopData = $dataDiseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($finalResult[0]['disease'] == $disease->name): ?>
                            <h4>Keterangan</h4>
                            <p><?php echo e($disease->description); ?></p>
                            <h4>Penanganan</h4>
                            <p><?php echo e($disease->treatment); ?></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">
                  Lihat hasil lainnya
                </button>
              </h2>
              <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
                <div class="accordion-body">
                    <?php $__currentLoopData = $finalResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($result['disease'] != $finalResult[0]['disease']): ?>
                            <?php
                                $dataGejala = explode(",",$result['symptoms']);
                                $dataCFRoles = explode(",", $result['cf_roles']);
                                $dataCFUsers = explode(",", $result['cf_users']);
                                $x = 1;
                            ?>
                            <div class="border-bottom p-3 border-danger border-5">
                                <h4>Penyakit <?php echo e(ucwords($result['disease'])); ?></h4>
                                <p>Gejala terkait yang dipilih pengguna :</p>
                                <table class="table table-bordered">
                                    <thead class="text-center">
                                        <th width="1%">No</th>
                                        <th>Gejala</th>
                                        <th>Tingkat Keyakinan Pakar</th>
                                        <th>Tingkat Keyakinan Pengguna</th>
                                    </thead>
                                    <tbody>
                                        <?php for($i = 0; $i < count($dataGejala); $i++): ?>
                                            <tr>
                                                <td><?php echo e($x++); ?></td>
                                                <td><?php echo e($dataGejala[$i]); ?></td>
                                                <?php switch($dataCFRoles[$i]):
                                                    case (0.2): ?>
                                                        <td class="text-center">10%-20%</td>
                                                        <?php break; ?>
                                                    <?php case (0.4): ?>
                                                        <td class="text-center">30%-40%</td>
                                                        <?php break; ?>
                                                    <?php case (0.6): ?>
                                                        <td class="text-center">50%-60%</td>
                                                        <?php break; ?>
                                                    <?php case (0.8): ?>
                                                        <td class="text-center">70%-80%</td>
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        <td class="text-center">90%-100%</td>
                                                <?php endswitch; ?>
                                                <?php switch($dataCFUsers[$i]):
                                                    case (0.2): ?>
                                                        <td class="text-center">10%-20%</td>
                                                        <?php break; ?>
                                                    <?php case (0.4): ?>
                                                        <td class="text-center">30%-40%</td>
                                                        <?php break; ?>
                                                    <?php case (0.6): ?>
                                                        <td class="text-center">50%-60%</td>
                                                        <?php break; ?>
                                                    <?php case (0.8): ?>
                                                        <td class="text-center">70%-80%</td>
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        <td class="text-center">90%-100%</td>
                                                <?php endswitch; ?>
                                            </tr>
                                        <?php endfor; ?>
                                    </tbody>
                                </table>
                                <h5>Presentase Perhitungan Sistem</h5>
                                <p>Kemiripan dengan kasus sebelumnya :</p>
                                <div class="progress">
                                    <div class="progress-bar bg-one"  style="width: <?php echo e($result['result_cbr']*100); ?>%;font-size:1rem;" role="progressbar"  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?php echo e($result['result_cbr']*100); ?>%</div>
                                </div>
                                <p>Hasil perhitungan algoritma Certainty Factor :</p>
                                <div class="progress">
                                    <div class="progress-bar bg-one" role="progressbar" style="width: <?php echo e($result['result_cf']*100); ?>%; font-size:1rem;" aria-valuemin="0" aria-valuemax="100"><?php echo e($result['result_cf']*100); ?>%</div>
                                </div>
                                <?php $__currentLoopData = $dataDiseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($result['disease'] == $disease->name): ?>
                                        <h4>Keterangan</h4>
                                        <p><?php echo e($disease->description); ?></p>
                                        <h4>Penanganan</h4>
                                        <p><?php echo e($disease->treatment); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
        </div>
        <div class="float-end mt-2">
            <a href="/diagnosa" class="btn bg-one font-color-default-w fw-semibold">Kembali ke halaman diagnosa</a>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\kuliah\project skripsi\sistem-pakar-anggrek-v2\sistem-pakar-anggrek-v2\resources\views/result.blade.php ENDPATH**/ ?>